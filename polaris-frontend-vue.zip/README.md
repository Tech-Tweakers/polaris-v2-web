### START PROJECT POLARIS FRONT END

npm install

npm run dev

Se tiver problemas com dependencias :

npm cache clean --force

rm -rf node_modules package-lock.json

npm install

npm run dev
