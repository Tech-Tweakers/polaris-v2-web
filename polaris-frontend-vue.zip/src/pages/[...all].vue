<template><h1>rota não encontrada</h1></template>

<script setup lang="ts">
</script>

<style>
</style>